# Author: rizul0x01
# Core modules for scopex reconnaissance tool

