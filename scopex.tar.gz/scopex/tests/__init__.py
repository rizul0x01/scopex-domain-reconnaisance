# Author: rizul0x01
# Test suite for scopex

