# Author: rizul0x01
# Plugins directory for scopex

